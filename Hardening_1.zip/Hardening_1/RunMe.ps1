Write-Host "This is windows 2019 Server hardening Script" -ForegroundColor Green
Write-Host "Please reach out to Avinash Malepati for errors" -ForegroundColor Gray
Write-Host "Orginal Policy is saved in Gptmpl_backup.inf" -ForegroundColor Red
Secedit /export /cfg .\GptTmpl_backup.inf

cp Windows_adm_files\AdmPwd.admx C:\Windows\PolicyDefinitions\
cp Windows_adm_files\MSS-legacy.admx C:\Windows\PolicyDefinitions\
cp Windows_adm_files\SecGuide.admx C:\Windows\PolicyDefinitions\
cp Windows_adm_files\en-US\AdmPwd.adml C:\Windows\PolicyDefinitions\en-US
cp Windows_adm_files\en-US\MSS-legacy.adml C:\Windows\PolicyDefinitions\en-US
cp Windows_adm_files\en-US\SecGuide.adml C:\Windows\PolicyDefinitions\en-US

.\harden.bat

net accounts /lockoutduration:15 
net accounts /lockoutthreshold:3
net accounts /MiNPWLEN:14
net accounts /minpwage:1
net accounts /maxpwage:60

Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\"            -Name fEncryptRPCTraffic -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\"           -Name MinEncryptionLeve -Value 3
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit\"     -Name ProcessCreationIncludeCmdLine_Enabled -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging\"   -Name EnableScriptBlockLogging -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization\"                 -Name NoLockScreenSlideshow -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\Wdigest\"          -Name UseLogonCredential -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\"                     -Name DisableWebPnPDownload -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\"                     -Name DisableHTTPPrinting -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System\"                          -Name DontDisplayNetworkSelectionUI -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat\"                       -Name DisableInventory -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System\"                          -Name EnableSmartScreen -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search\"                  -Name AllowIndexingEncryptedStoresOrItems -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System\"                          -Name " EnumerateLocalUsers" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client\"                    -Name "allowbasic" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client\"                    -Name "AllowDigest" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\"                   -Name "AllowBasic" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\CredUI\"           -Name "EnumerateAdministrators" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"            -Name "LocalAccountTokenFilterPolicy" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\"            -Name "fDisableCdm" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Application\"            -Name "MaxSize" -Value 32768
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Security\"               -Name "maxsize" -Value 196608
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\System\"                 -Name "MaxSize" -Value 32768
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer\"                       -Name "EnableUserControl" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Installer\"                       -Name "AlwaysInstallElevated" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer\"                        -Name "NoAutoplayfornonVolume" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\"         -Name "NoAutorun" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\Explorer\"         -Name "NoDriveTypeAutoRun" -Value 255
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\"            -Name "DisablePasswordSaving" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\"            -Name "fPromptForPassword" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\"                   -Name "DisableRunAs" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Rpc\"                          -Name "RestrictRemoteClients" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Client\"                    -Name "AllowUnencryptedTraffic" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\"                   -Name "AllowUnencryptedTraffic" -Value 0
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Netbt\Parameters\"                  -Name "NoNameReleaseOnDemand" -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters\"      -Name "RequireSecuritySignature" -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanManServer\Parameters\"           -Name "RequireSecuritySignature" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\"               -Name "CachedLogonsCount" -Value 4
#Set-ItemProperty -Path "HKLM: \SOFTWARE\Policies\Microsoft\Internet Explorer\Feeds\"                -Name "DisableEnclosureDownload" -Value 1
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\"                 -Name "DisableIPSourceRouting" -Value 2
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\"                  -Name "DisableIPSourceRouting" -Value 2
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\"                  -Name "EnableICMPRedirect" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation\"               -Name "AllowInsecureGuestAuth" -Value 0 
#Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\"           -Name "AllowProtectedCreds" -Value 1
#Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization\"                            -Name "DODownloadMode" -Value 0
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51\" -Name "ACSettingIndex" -Value 1
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\0e796bdb-100d-47d6-a2d5-f7d2daa51f51\" -Name "DCSettingIndex" -Value 1
Set-ItemProperty -Path "HKLM:Software\Microsoft\Windows\CurrentVersion\Policies\System" -Name InactivityTimeoutSecs -Value 900


Write-Host "The New administrator username is SCAdmin" -ForegroundColor Red